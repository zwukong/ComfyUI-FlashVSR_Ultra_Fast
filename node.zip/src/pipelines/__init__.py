from .flashvsr_full import FlashVSRFullPipeline
from .flashvsr_tiny import FlashVSRTinyPipeline
from .flashvsr_tiny_long import FlashVSRTinyLongPipeline